clc;
clear;

%% Load graph
net = xlsread('Graph.xlsx');
N = max(max(net));
M = length(net);
 
%% Adjacency matrix
A = zeros(N,N);
for i = 1 : M
    x = net(i,1);
    y = net(i,2);
    A(x,y) = 1;
    A(y,x) = 1;
end

%% Create Graph
G = graph(A);
f = figure; 
plot(G);
print(f,'-dmeta','graph.emf');

%% Degree centrality
DC = zeros(1,N);
for i = 1 : N
    DC(i) = degree(G,i);
end
d = distances(G);

%% Weighting based on Neighbors Degree (ND) policy
W = zeros(N,N);
for i = 1 : N
    for j = 1 : N
        if A(i,j) == 1
            Ni = find(A(i,:)==1);
            Nj = find(A(j,:)==1);
            
            K_Ni = 0;
            for k = Ni
                K_Ni = K_Ni + DC(k);
            end

            K_Nj = 0;
            for k = Nj
                K_Nj = K_Nj + DC(k);
            end
            
            W(i,j) = (K_Ni/DC(i) + K_Nj/DC(j));
            W(j,i) = W(i,j);
        end
    end
end

WW = ones(N,N);
for i = 1 : N
    for j = 1 : N
        if (i~=j)
            P = shortestpath(G, i,j);
            for k = 1: length(P)-1
                WW(i,j) = WW(i,j) * W(P(k),P(k+1));
            end
        else
            WW(i,j) = 0;
        end
    end
end

%% Node-Influence
I_Node = zeros(N,1);
DG = (2*M) / (N*(N-1));    % density
for i = 1 : N
    I_Node(i) = DC(i) / (DG+max(DC));
end

%% Local-Influence
I_Local = zeros(N,1);
for i = 1 : N
    Ni = find(A(i,:)==1);
    for k = Ni
        I_Local(i) = I_Local(i) + ((sqrt(W(i,k)*DC(i)))/(DC(i)+DC(k)));
    end
    I_Local(i) = I_Local(i) / DC(i);
end

%% Semi-Local-Influence
L = 3;
beta = 0.5;
d = distances(G);
Gv = [i];
I_Semi_Local = zeros(N,1);
for i = 1 : N
    tmp = 0;
    for l = 2 : L
        Ni = find(d(i,:)==l);
        Gv = [Gv Ni];
        for k = Ni
           tmp = tmp + ( sqrt(WW(i,k)*DC(i)) / (l*(DC(i)+DC(k))) );
        end
        I_Semi_Local(i) = I_Semi_Local(i) + (beta^l * tmp);
    end
    I_Semi_Local(i) = I_Semi_Local(i) / length(Gv);
end

%% Total-Influence
a1=0.25; a2=0.3; a3=0.45;
WSLC_Influence = zeros(N,1);
for i = 1 : N
    WSLC_Influence(i) = a1*I_Node(i)+a2*I_Local(i)+a3*I_Semi_Local(i);
end

[value, rank] = sort(WSLC_Influence,'descend');
VarNames = {'Rank', 'WSLC'};
T = table(rank,value, 'VariableNames',VarNames);
disp(T);

for i=1:N
    rank2(rank(i))=i;
end
data = 1:N;
data = [data' I_Node I_Local I_Semi_Local WSLC_Influence rank2'];
xlswrite('data.xlsx',data);
